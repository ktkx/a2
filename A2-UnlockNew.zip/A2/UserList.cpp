#include "UserList.h"


UserList::UserList()
{	 
	//initialize vector users
	//read in from text file
	//if not valid, exits 
	fstream afile;
	afile.open("login.txt",ios::in);
	if (!afile)
	{
		cout << "Error reading file!" << endl;
		exit(-1);
	}
	
	int i = 0; 
	//User u;
	string user;
	string pass;
	while (!afile.eof())
	{
		getline(afile,user, ' ');	 
		getline(afile, pass,'\n');	  
		User u(user,pass);	  
		users.push_back(u);	   	   
	}
	
	afile.close();	  	  
}

bool UserList::checkLockedAccount(string u)
{
/*
	cout << "Printing all " << endl;
	for (int i = 0; i < users.size();i++)
	{
		cout << users[i].getID() << endl;
		cout << users[i].getPass() << endl;
		cout << users[i].getLocked() << endl;
	}		
	
	for (int i = 0; i < users.size();i++)
	{
		if (u == users[i].getID())
		{
			if (users[i].getLocked())
				return true;	
			else 
				return false;
		}
	}	
	return false; 
*/	
	cout << "Size is " << lockedAccount.size() << endl;
	for (int i = 0; i < lockedAccount.size();i++)
	{
		if (u == lockedAccount[i].getID())			
			return true;
		else	
			return false;	
	}
}
		
bool UserList::validateUser(string u, string p)
{
	//iterate through array
	//match 	
	for (int i = 0; i < users.size();i++)
	{
		if ( (p == users[i].getPass()) && (u == users[i].getID()) )
			return true;	
	}	  
	return false;	 	 
}

void UserList::lockAccount(string id)
{
	//use id to search in array if found 
	// then set locked in user record to true
	// else do nothing
/*	for (int i = 0; i < users.size();i++)
	{
		if (id == users[i].getID())
		{
			users[i].setLockedTrue();
		}	 
	}	 
	cout << users[0].getLocked() << endl;
*/
	User u ( id, "temp");
	lockedAccount.push_back(u);
}

void UserList::unlockAccount(string id)
{
/*	bool found = false;
	int mark = 0;
	for (int i = 0; i < users.size();i++)
	{
		if (id == users[i].getID())
		{
			users[i].setLockedFalse();			
			cout << "Account '"<< users[mark].getID() << "' successfully unlocked " << endl;
			found  = true;
			break;		
		}	 
	}	 
	if (found == false)
		cout << "You userId is not found! " << endl;
*/

	for (int i = 0; i < lockedAccount.size();i++)
	{
		if (id == lockedAccount[i].getID())
		{
			lockedAccount[i].setID(" ");
		}	 
	}	 
	
}

