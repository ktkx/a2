#include "System.h"

int main() {
	System s;
	
	s.run();		
}

